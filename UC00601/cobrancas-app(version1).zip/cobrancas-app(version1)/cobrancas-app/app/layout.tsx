import './globals.css'
import type { Metadata } from 'next'
import Link from 'next/link'
import { Inter } from 'next/font/google'
import { obterSessao } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import LogoutButton from '@/components/LogoutButton'
import { Badge } from '@/components/Badge'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })

export const metadata: Metadata = {
  title: 'CobraFácil — Gestão de cobranças',
  description: 'Centraliza clientes, cobranças, notificações, pagamentos, planos de pagamento e reclamações.',
}

async function obterContadores(role: 'EMPRESA' | 'CLIENTE' | undefined, userId: string | undefined) {
  if (!role || !userId) return { notificacoesPorLer: 0, reclamacoesPendentes: 0 }

  if (role === 'CLIENTE') {
    const notificacoesPorLer = await prisma.notificacao.count({ where: { clienteId: userId, lida: false } })
    return { notificacoesPorLer, reclamacoesPendentes: 0 }
  }

  const reclamacoesPendentes = await prisma.reclamacao.count({
    where: { estado: { in: ['PENDENTE', 'EM_ANALISE'] }, cliente: { empresaId: userId } },
  })
  return { notificacoesPorLer: 0, reclamacoesPendentes }
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await obterSessao()
  const role = session?.user?.role
  const { notificacoesPorLer, reclamacoesPendentes } = await obterContadores(role, session?.user?.id)

  return (
    <html lang="pt" className={inter.variable}>
      <body className="min-h-screen bg-slate-50 font-sans text-slate-900 antialiased">
        <header className="border-b border-slate-200 bg-white">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
            <Link href="/" className="text-xl font-extrabold tracking-tight">
              CobraFácil
            </Link>
            <nav className="flex items-center gap-5 text-sm font-medium text-slate-600">
              {role === 'EMPRESA' && (
                <>
                  <Link href="/dashboard" className="hover:text-slate-900">Dashboard</Link>
                  <Link href="/cobrancas" className="hover:text-slate-900">Cobranças</Link>
                  <Link href="/clientes" className="hover:text-slate-900">Clientes</Link>
                  <Link href="/reclamacoes" className="relative hover:text-slate-900">
                    Reclamações
                    {reclamacoesPendentes > 0 && (
                      <Badge className="absolute -right-4 -top-2 bg-red-100 text-red-700">{reclamacoesPendentes}</Badge>
                    )}
                  </Link>
                  <LogoutButton />
                </>
              )}
              {role === 'CLIENTE' && (
                <>
                  <Link href="/cliente" className="relative hover:text-slate-900">
                    A minha área
                    {notificacoesPorLer > 0 && (
                      <Badge className="absolute -right-4 -top-2 bg-red-100 text-red-700">{notificacoesPorLer}</Badge>
                    )}
                  </Link>
                  <LogoutButton />
                </>
              )}
              {!role && (
                <>
                  <Link href="/login" className="hover:text-slate-900">Entrar</Link>
                  <Link href="/registar" className="btn">Criar conta</Link>
                </>
              )}
            </nav>
          </div>
        </header>
        {children}
        <footer className="mx-auto max-w-6xl px-6 py-10 text-xs text-slate-400">
          CobraFácil — gestão e acompanhamento de cobranças.
        </footer>
      </body>
    </html>
  )
}
