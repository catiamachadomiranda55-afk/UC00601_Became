'use client'

import { signOut } from 'next-auth/react'
import { LogOut } from 'lucide-react'

export default function LogoutButton() {
  return (
    <button
      onClick={() => signOut({ callbackUrl: '/' })}
      className="flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-slate-900"
    >
      <LogOut className="h-4 w-4" />
      Sair
    </button>
  )
}
