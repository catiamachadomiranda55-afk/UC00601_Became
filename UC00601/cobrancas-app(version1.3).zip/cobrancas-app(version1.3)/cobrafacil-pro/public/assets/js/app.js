/* CobraFácil — utilitários partilhados */
(function () {
  "use strict";

  /* Escapa texto antes de o inserir com innerHTML (evita injeção de HTML). */
  window.esc = function (valor) {
    return String(valor).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  };

  /* Mensagem breve no canto do ecrã (substitui o alert()). */
  window.toast = function (texto, tipo) {
    var pilha = document.querySelector(".toast-stack");
    if (!pilha) {
      pilha = document.createElement("div");
      pilha.className = "toast-stack";
      pilha.setAttribute("role", "status");
      pilha.setAttribute("aria-live", "polite");
      document.body.appendChild(pilha);
    }
    var t = document.createElement("div");
    t.className = "toast" + (tipo === "erro" ? " erro-t" : "");
    t.textContent = texto;
    pilha.appendChild(t);
    setTimeout(function () { t.remove(); }, 3500);
  };

  /* Menu em ecrãs pequenos. */
  document.addEventListener("DOMContentLoaded", function () {
    var botao = document.querySelector(".nav-toggle");
    var menu = document.getElementById("menu-principal");
    if (!botao || !menu) return;
    botao.addEventListener("click", function () {
      var aberto = menu.classList.toggle("open");
      botao.setAttribute("aria-expanded", aberto ? "true" : "false");
    });
  });
})();

/* Terminar sessão (demonstração): limpa o perfil guardado ao carregar em "Sair". */
document.addEventListener("click", function (e) {
  var a = e.target.closest && e.target.closest(".side-logout, .main-nav a[href$='login/login.html']");
  if (a && a.classList.contains("side-logout")) { try { sessionStorage.removeItem("cf_perfil"); } catch (err) {} }
});
