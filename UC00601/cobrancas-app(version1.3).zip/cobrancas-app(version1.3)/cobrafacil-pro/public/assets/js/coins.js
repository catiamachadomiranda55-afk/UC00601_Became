/* CobraFácil — moeda 3D decorativa da página inicial (Three.js).
   Desliga-se sozinha se o navegador não tiver WebGL ou se a pessoa preferir menos movimento. */
(function () {
  "use strict";
  var canvas = document.querySelector(".coin3d");
  if (!canvas || !window.THREE) return;

  var reduzido = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduzido) { canvas.style.display = "none"; return; }

  var renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });
  } catch (e) { canvas.style.display = "none"; return; }

  var largura = canvas.clientWidth || 240, altura = canvas.clientHeight || 240;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(largura, altura, false);

  var cena = new THREE.Scene();
  var camara = new THREE.PerspectiveCamera(32, largura / altura, 0.1, 50);
  camara.position.set(0, 0, 8.2);

  cena.add(new THREE.AmbientLight(0xffffff, 0.75));
  var sol = new THREE.DirectionalLight(0xffffff, 1.6); sol.position.set(3, 4, 6); cena.add(sol);
  var recorte = new THREE.PointLight(0x9fb0ff, 1.2, 30); recorte.position.set(-5, -2, 4); cena.add(recorte);

  /* Textura da face: círculo dourado com anel e símbolo € */
  function face(simbolo) {
    var c = document.createElement("canvas"); c.width = c.height = 256;
    var g = c.getContext("2d");
    var grad = g.createRadialGradient(100, 90, 20, 128, 128, 128);
    grad.addColorStop(0, "#ffe08a"); grad.addColorStop(1, "#d99a1d");
    g.fillStyle = grad; g.fillRect(0, 0, 256, 256);
    g.strokeStyle = "rgba(120,70,0,.45)"; g.lineWidth = 8;
    g.beginPath(); g.arc(128, 128, 104, 0, Math.PI * 2); g.stroke();
    if (simbolo) {
      g.fillStyle = "#8a5300"; g.font = "700 150px Inter, Arial, sans-serif";
      g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(simbolo, 128, 138);
    }
    var t = new THREE.CanvasTexture(c); t.anisotropy = 4; return t;
  }

  var lado = new THREE.MeshStandardMaterial({ color: 0xcf8f14, metalness: 0.55, roughness: 0.35 });
  function moeda(raio, espessura, simbolo) {
    var f = new THREE.MeshStandardMaterial({ map: face(simbolo), metalness: 0.45, roughness: 0.4 });
    var m = new THREE.Mesh(new THREE.CylinderGeometry(raio, raio, espessura, 64), [lado, f, f]);
    m.rotation.x = Math.PI / 2;       /* a face aponta para a câmara */
    var g = new THREE.Group(); g.add(m); return g;
  }

  var grupo = new THREE.Group(); cena.add(grupo);
  var principal = moeda(1.25, 0.22, "€"); grupo.add(principal);
  var pequena1 = moeda(0.5, 0.1, "€"); pequena1.position.set(1.7, 1.2, -0.4); grupo.add(pequena1);
  var pequena2 = moeda(0.38, 0.08, ""); pequena2.position.set(-1.7, -1.1, 0.2); grupo.add(pequena2);

  var rx = 0, ry = 0;
  window.addEventListener("pointermove", function (e) {
    ry = (e.clientX / window.innerWidth - 0.5) * 0.7;
    rx = (e.clientY / window.innerHeight - 0.5) * 0.5;
  }, { passive: true });

  var visivel = true;
  if ("IntersectionObserver" in window) {
    new IntersectionObserver(function (en) { visivel = en[0].isIntersecting; }).observe(canvas);
  }

  /* Evento "cf:pago": as moedas dão uma volta rápida (usado ao marcar uma cobrança como paga). */
  var impulso = 0, angulo = 0, ultimo = performance.now();
  window.addEventListener("cf:pago", function () { impulso = 1; });

  var t0 = performance.now();
  function animar(agora) {
    requestAnimationFrame(animar);
    if (!visivel || document.hidden) { ultimo = agora; return; }
    var t = (agora - t0) / 1000, dt = Math.min((agora - ultimo) / 1000, 0.1);
    ultimo = agora;
    angulo += (0.9 + impulso * 9) * dt;
    impulso *= 0.95;
    grupo.position.y = Math.sin(impulso * Math.PI) * 0.35;
    principal.rotation.y = angulo;
    pequena1.rotation.y = -t * 1.3; pequena1.position.y = 1.2 + Math.sin(t * 1.4) * 0.12;
    pequena2.rotation.y = t * 1.1;  pequena2.position.y = -1.1 + Math.cos(t * 1.2) * 0.1;
    grupo.rotation.x += (rx - grupo.rotation.x) * 0.06;
    grupo.rotation.y += (ry - grupo.rotation.y) * 0.06;
    renderer.render(cena, camara);
  }
  requestAnimationFrame(animar);
})();
