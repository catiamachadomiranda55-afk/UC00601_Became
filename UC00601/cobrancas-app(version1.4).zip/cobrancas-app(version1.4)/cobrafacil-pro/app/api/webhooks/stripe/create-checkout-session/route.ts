import { NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe'; // Utiliza a instância do Stripe já existente no projeto
import { prisma } from '@/lib/prisma'; // Utiliza o Prisma para aceder à base de dados

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { cobrancaId } = body;

    // Opcional: Buscar os dados reais da cobrança/fatura na base de dados
    // const cobranca = await prisma.cobranca.findUnique({ where: { id: cobrancaId } });

    // Criação da sessão de Checkout do Stripe
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'eur',
            product_data: {
              name: `Fatura / Cobrança #${cobrancaId || 'Geral'}`,
            },
            unit_amount: 25000, // Valor em cêntimos (ex: 250,00 € = 25000)
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${process.env.NEXTAUTH_URL}/cliente/cliente.html?success=true`,
      cancel_url: `${process.env.NEXTAUTH_URL}/cliente/cliente.html?canceled=true`,
    });

    return NextResponse.json({ url: session.url });
  } catch (error: any) {
    console.error('Erro ao criar sessão Stripe:', error);
    return NextResponse.json({ error: error.message || 'Erro interno ao processar pagamento.' }, { status: 500 });
  }
}