import { DefaultSession } from 'next-auth'

declare module 'next-auth' {
  interface Session {
    user: {
      id: string
      role: 'EMPRESA' | 'CLIENTE'
    } & DefaultSession['user']
  }

  interface User {
    role: 'EMPRESA' | 'CLIENTE'
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id: string
    role: 'EMPRESA' | 'CLIENTE'
  }
}
