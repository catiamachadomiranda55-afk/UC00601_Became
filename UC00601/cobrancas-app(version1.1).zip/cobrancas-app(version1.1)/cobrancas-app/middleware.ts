import { NextResponse } from 'next/server'
import { getToken } from 'next-auth/jwt'
import type { NextRequest } from 'next/server'

const ROTAS_EMPRESA = ['/dashboard', '/cobrancas', '/clientes', '/reclamacoes']
const ROTAS_CLIENTE = ['/cliente']

// Nota de segurança: o middleware do Next.js sofreu um bypass crítico
// (CVE-2025-29927, corrigido em 14.2.25). Por isso, cada página protegida
// volta a verificar a sessão do lado do servidor via exigirEmpresa()/
// exigirCliente() em lib/auth.ts — o middleware é apenas a primeira barreira.
export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl
  const precisaEmpresa = ROTAS_EMPRESA.some((rota) => pathname.startsWith(rota))
  const precisaCliente = ROTAS_CLIENTE.some((rota) => pathname.startsWith(rota))
  if (!precisaEmpresa && !precisaCliente) return NextResponse.next()

  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET })

  if (!token || (precisaEmpresa && token.role !== 'EMPRESA') || (precisaCliente && token.role !== 'CLIENTE')) {
    const url = req.nextUrl.clone()
    url.pathname = '/login'
    return NextResponse.redirect(url)
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*', '/cobrancas/:path*', '/clientes/:path*', '/reclamacoes/:path*', '/cliente/:path*'],
}
