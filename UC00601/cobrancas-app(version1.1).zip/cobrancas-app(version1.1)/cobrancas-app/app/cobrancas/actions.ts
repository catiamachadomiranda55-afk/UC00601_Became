'use server'

import { prisma } from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { exigirEmpresa } from '@/lib/auth'
import { moedaPorPais, obterTaxa, converter } from '@/lib/moedas'

export async function criarCobranca(fd: FormData) {
  const empresa = await exigirEmpresa()
  const clienteId = String(fd.get('clienteId'))
  const cliente = await prisma.cliente.findFirst({ where: { id: clienteId, empresaId: empresa.id } })
  if (!cliente) throw new Error('Cliente não encontrado')

  await prisma.cobranca.create({
    data: {
      descricao: String(fd.get('descricao')),
      valor: Number(fd.get('valor')),
      dataLimite: new Date(String(fd.get('dataLimite'))),
      empresaId: empresa.id,
      clienteId,
    },
  })

  revalidatePath('/dashboard')
  revalidatePath('/cobrancas')
}

export async function marcarPago(fd: FormData) {
  const empresa = await exigirEmpresa()
  const id = String(fd.get('id'))
  const c = await prisma.cobranca.findFirst({ where: { id, empresaId: empresa.id }, include: { cliente: true } })
  if (!c) return

  const moeda = moedaPorPais(c.cliente.pais)
  const taxa = await obterTaxa(moeda)
  const valorConvertido = converter(c.valor, taxa)

  await prisma.cobranca.update({ where: { id }, data: { estado: 'PAGO' } })
  await prisma.pagamento.create({
    data: {
      valor: valorConvertido,
      moeda,
      valorBaseEur: c.valor,
      metodo: 'Registo manual (empresa)',
      cobrancaId: id,
      clienteId: c.clienteId,
    },
  })

  revalidatePath('/dashboard')
  revalidatePath('/cobrancas')
  revalidatePath('/cliente')
}

export async function notificar(fd: FormData) {
  const empresa = await exigirEmpresa()
  const id = String(fd.get('id'))
  const c = await prisma.cobranca.findFirst({ where: { id, empresaId: empresa.id } })
  if (!c) return

  await prisma.notificacao.create({
    data: {
      tipo: 'MANUAL',
      mensagem: `Aviso de cobrança: ${c.descricao}. Valor: ${c.valor.toFixed(2)} €.`,
      cobrancaId: id,
      clienteId: c.clienteId,
    },
  })

  revalidatePath('/cobrancas')
  revalidatePath('/cliente')
}
