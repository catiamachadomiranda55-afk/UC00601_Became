import { NextResponse } from 'next/server'
import type Stripe from 'stripe'
import { prisma } from '@/lib/prisma'
import { obterStripe } from '@/lib/stripe'

// Webhook do Stripe: confirma pagamentos por cartão e marca a cobrança como
// paga. Idempotente (verifica se já existe um Pagamento Stripe para a mesma
// cobrança antes de criar um novo).
export async function POST(req: Request) {
  const stripe = obterStripe()
  const segredo = process.env.STRIPE_WEBHOOK_SECRET

  if (!stripe || !segredo) {
    return NextResponse.json({ erro: 'Stripe não configurado' }, { status: 400 })
  }

  const corpo = await req.text()
  const assinatura = req.headers.get('stripe-signature')

  let evento: Stripe.Event
  try {
    evento = stripe.webhooks.constructEvent(corpo, assinatura ?? '', segredo)
  } catch {
    return NextResponse.json({ erro: 'Assinatura inválida' }, { status: 400 })
  }

  if (evento.type === 'checkout.session.completed') {
    const sessao = evento.data.object as Stripe.Checkout.Session
    const cobrancaId = sessao.metadata?.cobrancaId
    const clienteId = sessao.metadata?.clienteId
    const valorBaseEur = Number(sessao.metadata?.valorBaseEur || 0)
    const moeda = sessao.metadata?.moeda || 'EUR'

    if (cobrancaId && clienteId) {
      const jaExiste = await prisma.pagamento.findFirst({ where: { cobrancaId, metodo: 'Stripe' } })
      if (!jaExiste) {
        await prisma.$transaction([
          prisma.cobranca.update({ where: { id: cobrancaId }, data: { estado: 'PAGO' } }),
          prisma.pagamento.create({
            data: {
              valor: (sessao.amount_total ?? 0) / 100,
              moeda,
              valorBaseEur,
              metodo: 'Stripe',
              referencia: sessao.id,
              cobrancaId,
              clienteId,
            },
          }),
          prisma.notificacao.create({
            data: {
              tipo: 'PAGAMENTO_CONFIRMADO',
              mensagem: 'Recebemos o seu pagamento com cartão. Obrigado!',
              cobrancaId,
              clienteId,
            },
          }),
        ])
      }
    }
  }

  return NextResponse.json({ recebido: true })
}
