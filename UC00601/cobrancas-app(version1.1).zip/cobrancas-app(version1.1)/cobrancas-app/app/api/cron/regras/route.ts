import { NextResponse } from 'next/server'
import { regrasAutomaticas } from '@/lib/notificacoes'
import { atualizarTaxasOnline } from '@/lib/moedas'

// Endpoint chamado periodicamente (ver vercel.json) para aplicar descontos,
// multas e notificações automáticas a todas as empresas, e opcionalmente
// atualizar taxas de câmbio. Protegido por CRON_SECRET.
export async function GET(req: Request) {
  const cabecalhoAuth = req.headers.get('authorization')
  if (process.env.CRON_SECRET && cabecalhoAuth !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ erro: 'Não autorizado' }, { status: 401 })
  }

  const resultado = await regrasAutomaticas()
  const taxasAtualizadas = await atualizarTaxasOnline()

  return NextResponse.json({
    executado: true,
    em: new Date().toISOString(),
    ...resultado,
    taxasAtualizadas,
  })
}
