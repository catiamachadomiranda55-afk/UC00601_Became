'use server'

import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { prisma } from '@/lib/prisma'
import { exigirCliente } from '@/lib/auth'
import { moedaPorPais, obterTaxa, converter } from '@/lib/moedas'
import { obterStripe } from '@/lib/stripe'

export async function pagar(fd: FormData) {
  const sessao = await exigirCliente()
  const id = String(fd.get('id'))
  const metodo = String(fd.get('metodo') || 'Registo manual')

  const cliente = await prisma.cliente.findUnique({ where: { id: sessao.id } })
  const cobranca = await prisma.cobranca.findFirst({ where: { id, clienteId: sessao.id } })
  if (!cliente || !cobranca) return

  const moeda = moedaPorPais(cliente.pais)
  const taxa = await obterTaxa(moeda)
  const valorConvertido = converter(cobranca.valor, taxa)

  await prisma.cobranca.update({ where: { id }, data: { estado: 'PAGO' } })
  await prisma.pagamento.create({
    data: { valor: valorConvertido, moeda, valorBaseEur: cobranca.valor, metodo, cobrancaId: id, clienteId: sessao.id },
  })

  revalidatePath('/cliente')
  revalidatePath('/dashboard')
  revalidatePath('/cobrancas')
}

export async function pagarComStripe(fd: FormData) {
  const sessao = await exigirCliente()
  const id = String(fd.get('id'))

  const cliente = await prisma.cliente.findUnique({ where: { id: sessao.id } })
  const cobranca = await prisma.cobranca.findFirst({ where: { id, clienteId: sessao.id } })
  const stripe = obterStripe()

  if (!cliente || !cobranca || !stripe) {
    redirect('/cliente?erro=pagamento-indisponivel')
  }

  const moeda = moedaPorPais(cliente.pais)
  const taxa = await obterTaxa(moeda)
  const valorConvertido = converter(cobranca.valor, taxa)
  const baseUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000'

  const sessaoCheckout = await stripe.checkout.sessions.create({
    mode: 'payment',
    payment_method_types: ['card'],
    line_items: [
      {
        price_data: {
          currency: moeda.toLowerCase(),
          product_data: { name: cobranca.descricao },
          unit_amount: Math.round(valorConvertido * 100),
        },
        quantity: 1,
      },
    ],
    metadata: {
      cobrancaId: cobranca.id,
      clienteId: sessao.id,
      valorBaseEur: String(cobranca.valor),
      moeda,
    },
    success_url: `${baseUrl}/cliente?pago=1`,
    cancel_url: `${baseUrl}/cliente?cancelado=1`,
  })

  await prisma.cobranca.update({ where: { id: cobranca.id }, data: { stripeSessionId: sessaoCheckout.id } })
  redirect(sessaoCheckout.url!)
}

export async function negociar(fd: FormData) {
  const sessao = await exigirCliente()
  const id = String(fd.get('id'))
  const numeroPrestacoes = Math.min(6, Math.max(2, Number(fd.get('numeroPrestacoes')) || 3))

  const cobranca = await prisma.cobranca.findFirst({ where: { id, clienteId: sessao.id } })
  if (!cobranca) return

  await prisma.cobranca.update({ where: { id }, data: { estado: 'NEGOCIACAO' } })

  const valorBase = Math.floor((cobranca.valor / numeroPrestacoes) * 100) / 100
  const prestacoesData = Array.from({ length: numeroPrestacoes }, (_, i) => {
    const numero = i + 1
    const dataVencimento = new Date(cobranca.dataLimite)
    dataVencimento.setMonth(dataVencimento.getMonth() + numero)
    const valor =
      numero === numeroPrestacoes
        ? Math.round((cobranca.valor - valorBase * (numeroPrestacoes - 1)) * 100) / 100
        : valorBase
    return { numero, valor, dataVencimento }
  })

  await prisma.planoPagamento.upsert({
    where: { cobrancaId: id },
    update: { numeroPrestacoes, prestacoes: { deleteMany: {}, create: prestacoesData } },
    create: { cobrancaId: id, clienteId: sessao.id, numeroPrestacoes, prestacoes: { create: prestacoesData } },
  })

  revalidatePath('/cliente')
  revalidatePath('/dashboard')
}

export async function pagarPrestacao(fd: FormData) {
  const sessao = await exigirCliente()
  const id = String(fd.get('id'))

  const prestacao = await prisma.prestacao.findUnique({
    where: { id },
    include: { plano: { include: { cobranca: true } } },
  })
  if (!prestacao || prestacao.plano.clienteId !== sessao.id) return

  await prisma.prestacao.update({ where: { id }, data: { estado: 'PAGA' } })
  await prisma.pagamento.create({
    data: {
      valor: prestacao.valor,
      moeda: prestacao.plano.cobranca.moeda,
      valorBaseEur: prestacao.valor,
      metodo: 'Prestação',
      cobrancaId: prestacao.plano.cobrancaId,
      clienteId: sessao.id,
    },
  })

  const restantes = await prisma.prestacao.count({ where: { planoId: prestacao.planoId, estado: { not: 'PAGA' } } })
  if (restantes === 0) {
    await prisma.cobranca.update({ where: { id: prestacao.plano.cobrancaId }, data: { estado: 'PAGO' } })
  }

  revalidatePath('/cliente')
  revalidatePath('/dashboard')
}

export async function reclamar(fd: FormData) {
  const sessao = await exigirCliente()
  const mensagem = String(fd.get('mensagem') || '').trim()
  if (!mensagem) return

  await prisma.reclamacao.create({ data: { clienteId: sessao.id, mensagem } })

  revalidatePath('/cliente')
  revalidatePath('/reclamacoes')
}

export async function marcarNotificacoesLidas() {
  const sessao = await exigirCliente()
  await prisma.notificacao.updateMany({ where: { clienteId: sessao.id, lida: false }, data: { lida: true } })
  revalidatePath('/cliente')
}
