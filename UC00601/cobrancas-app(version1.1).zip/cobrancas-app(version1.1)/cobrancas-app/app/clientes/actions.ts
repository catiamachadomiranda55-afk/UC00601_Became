'use server'

import bcrypt from 'bcryptjs'
import { revalidatePath } from 'next/cache'
import { prisma } from '@/lib/prisma'
import { exigirEmpresa } from '@/lib/auth'
import { enviarEmail } from '@/lib/email'
import { gerarPasswordTemporaria } from '@/lib/utils'

export type EstadoCriarCliente = {
  erro: string
  passwordTemporaria: string | null
  emailCliente: string | null
}

export async function criarCliente(_estadoAnterior: EstadoCriarCliente, fd: FormData): Promise<EstadoCriarCliente> {
  const empresa = await exigirEmpresa()
  const nome = String(fd.get('nome') || '').trim()
  const email = String(fd.get('email') || '').trim().toLowerCase()
  const pais = String(fd.get('pais') || 'PT')

  if (!nome || !email) {
    return { erro: 'Preencha nome e e-mail.', passwordTemporaria: null, emailCliente: null }
  }

  const existente = await prisma.cliente.findUnique({ where: { email } })
  if (existente) {
    return { erro: 'Já existe um cliente com este e-mail.', passwordTemporaria: null, emailCliente: null }
  }

  const passwordTemporaria = gerarPasswordTemporaria()
  const passwordHash = await bcrypt.hash(passwordTemporaria, 12)

  await prisma.cliente.create({ data: { nome, email, pais, passwordHash, empresaId: empresa.id } })

  await enviarEmail(
    email,
    'O seu acesso à área de cliente — CobraFácil',
    `<p>Olá ${nome},</p><p>A sua conta foi criada por ${empresa.name}.</p><p>E-mail: <b>${email}</b><br/>Palavra-passe temporária: <b>${passwordTemporaria}</b></p><p>Recomendamos que a altere após o primeiro acesso.</p>`
  ).catch(() => {})

  revalidatePath('/clientes')
  revalidatePath('/cobrancas')

  return { erro: '', passwordTemporaria, emailCliente: email }
}
