'use server'

import bcrypt from 'bcryptjs'
import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'

export type EstadoRegisto = { erro: string }

export async function registarEmpresa(_estadoAnterior: EstadoRegisto, fd: FormData): Promise<EstadoRegisto> {
  const nome = String(fd.get('nome') || '').trim()
  const email = String(fd.get('email') || '').trim().toLowerCase()
  const password = String(fd.get('password') || '')

  if (!nome || !email) {
    return { erro: 'Preencha todos os campos.' }
  }
  if (password.length < 8) {
    return { erro: 'A palavra-passe deve ter pelo menos 8 caracteres.' }
  }

  const existente = await prisma.empresa.findUnique({ where: { email } })
  if (existente) {
    return { erro: 'Já existe uma conta com este e-mail.' }
  }

  const passwordHash = await bcrypt.hash(password, 12)
  await prisma.empresa.create({ data: { nome, email, passwordHash } })

  return redirect('/login')
}
