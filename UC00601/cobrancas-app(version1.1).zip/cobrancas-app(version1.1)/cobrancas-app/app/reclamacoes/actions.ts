'use server'

import { revalidatePath } from 'next/cache'
import { prisma } from '@/lib/prisma'
import { exigirEmpresa } from '@/lib/auth'

export async function responderReclamacao(fd: FormData) {
  const empresa = await exigirEmpresa()
  const id = String(fd.get('id'))
  const resposta = String(fd.get('resposta') || '').trim()
  const novoEstado = String(fd.get('estado') || 'RESOLVIDA') as 'EM_ANALISE' | 'RESOLVIDA'

  const reclamacao = await prisma.reclamacao.findUnique({ where: { id }, include: { cliente: true } })
  if (!reclamacao || reclamacao.cliente.empresaId !== empresa.id) return

  await prisma.reclamacao.update({
    where: { id },
    data: {
      resposta: resposta || reclamacao.resposta,
      estado: novoEstado,
      respondidoEm: new Date(),
    },
  })

  if (resposta) {
    await prisma.notificacao.create({
      data: {
        tipo: 'RECLAMACAO_RESPONDIDA',
        mensagem: `A sua reclamação recebeu uma resposta: "${resposta}"`,
        clienteId: reclamacao.clienteId,
      },
    })
  }

  revalidatePath('/reclamacoes')
  revalidatePath('/cliente')
}
