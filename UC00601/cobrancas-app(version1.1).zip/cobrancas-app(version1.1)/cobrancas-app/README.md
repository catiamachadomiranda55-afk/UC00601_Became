# CobraFácil — Gestão de Cobranças

Aplicação Next.js 14 (App Router) + TypeScript + Prisma para gerir clientes,
cobranças, notificações automáticas, pagamentos, planos de pagamento,
reclamações e moeda estrangeira, com autenticação real.

## Requisitos
- Node.js 20+
- npm

## Instalação

```bash
npm install
cp .env.example .env
# edite .env — pelo menos gere um NEXTAUTH_SECRET:
#   openssl rand -base64 32
npx prisma db push
npm run db:seed
npm run dev
```

Abrir http://localhost:3000

### Contas de demonstração (criadas pelo seed)
| Perfil | E-mail | Palavra-passe |
|---|---|---|
| Empresa | empresa@demo.pt | empresa123 |
| Cliente (Portugal, EUR) | cliente@demo.pt | cliente123 |
| Cliente (Brasil, BRL) | cliente.br@demo.pt | cliente123 |

**Altere estas palavras-passe antes de usar em produção.**

## Estrutura
- `/login`, `/registar` — autenticação real (NextAuth + palavra-passe encriptada)
- `/dashboard`, `/cobrancas`, `/clientes`, `/reclamacoes` — área da empresa
- `/cliente` — área do cliente: pagamento, negociação e reclamações
- `/api/cron/regras` — regras automáticas (ver abaixo)
- `/api/webhooks/stripe` — confirmação de pagamentos por cartão
- `prisma/schema.prisma` — base de dados (SQLite por omissão)
- `lib/` — regras de negócio, autenticação, moedas, e-mail, Stripe

## Funcionalidades

### Autenticação real
NextAuth (Credentials) com palavras-passe encriptadas (bcrypt), sessão JWT e
duas camadas de proteção de rotas: `middleware.ts` **e** verificação de
sessão em cada página via `lib/auth.ts`. A segunda camada existe porque o
middleware do Next.js sozinho já teve um bypass crítico conhecido
(CVE-2025-29927, corrigido no Next 14.2.25 — por isso a dependência do
Next está fixada em `^14.2.25`).

Empresas registam-se em `/registar`. Clientes recebem acesso quando a
empresa os adiciona em `/clientes` (é gerada uma palavra-passe temporária,
mostrada uma vez e enviada por e-mail se o SMTP estiver configurado).

### Notificações automáticas
`lib/notificacoes.ts` aplica, por cobrança pendente:
- **7→4 dias antes**: aviso + 3% de desconto
- **3→1 dias antes**: aviso
- **Dia do prazo**: aviso com destaque de pagamento
- **Depois do prazo**: estado "Em atraso" + multa de 5%

É idempotente (não duplica avisos) e corre de duas formas:
1. Automaticamente sempre que a empresa abre o dashboard.
2. Via `GET /api/cron/regras` (protegido por `CRON_SECRET`), agendado
   diariamente às 08:00 em `vercel.json` — se não usar a Vercel, aponte
   qualquer agendador externo (ex. cron-job.org) para este endpoint com o
   cabeçalho `Authorization: Bearer <CRON_SECRET>`.

### Pagamentos
- **Cartão (Stripe Checkout)**: ativo automaticamente quando
  `STRIPE_SECRET_KEY`, `STRIPE_PUBLIC_KEY` e `STRIPE_WEBHOOK_SECRET` estão
  definidos. Sem estas chaves, o botão de cartão fica oculto.
- **Registo manual**: transferência, referência ou "um clique" — sempre
  disponível, tal como no MVP original.
- Configurar o webhook do Stripe (CLI local): `stripe listen --forward-to
  localhost:3000/api/webhooks/stripe`.

### Planos de pagamento
Negociação em 2, 3 ou 6 prestações, cada uma com valor e data de vencimento
próprios (a última prestação absorve o arredondamento). O cliente paga cada
prestação individualmente; a cobrança fica "Paga" quando todas estiverem
liquidadas.

### Reclamações
O cliente reclama a partir da sua área; a empresa vê tudo em `/reclamacoes`,
responde e marca como "Em análise" ou "Resolvida". O cliente é notificado
da resposta.

### Moeda estrangeira
A empresa fatura sempre em EUR. `lib/moedas.ts` mostra e cobra o
equivalente na moeda do país do cliente (mapeamento em `MOEDA_POR_PAIS`,
com suporte a Portugal, países lusófonos — Brasil, Angola, Moçambique, Cabo
Verde — e outros mercados comuns). As taxas de câmbio de referência ficam
em `TAXAS_REFERENCIA` e podem ser atualizadas automaticamente definindo
`EXCHANGE_RATE_API_URL` (ex.: `https://api.frankfurter.app/latest?from=EUR`,
gratuito e sem chave) — a atualização corre junto com o cron diário.

### Interface
Tailwind CSS, tipografia Inter, componentes reutilizáveis (`components/`).

## Correções feitas ao projeto original
- `prisma/schema.prisma`: `email String unique` não compilava — faltava o
  `@` (`@unique`). Schema também foi reorganizado e ampliado.
- `tsconfig.json`: faltava `baseUrl`/`paths` para o alias `@/*`, que já era
  usado em todo o código — os imports não resolviam.
- `app/layout.tsx`: o layout raiz não tinha `<html>`/`<body>`, obrigatórios
  no App Router.
- Todas as queries de leitura/escrita passaram a filtrar por
  `empresaId`/`clienteId` da sessão autenticada — no MVP original, o
  dashboard e a área do cliente mostravam dados de **todas** as empresas e
  o primeiro cliente da base de dados, independentemente de quem tinha
  sessão iniciada.
- Cálculo de dias até ao prazo mudou de subtração bruta de timestamps para
  comparação por data (`lib/rules.ts::diferencaDias`), evitando avisos a
  disparar no dia errado por causa da hora do dia.

## Variáveis de ambiente
Ver `.env.example`. Só `DATABASE_URL` e `NEXTAUTH_SECRET` são obrigatórias
para correr localmente; Stripe, SMTP, cron e câmbio automático são todos
opcionais e têm um comportamento de reserva (*fallback*) sensato quando
não configurados.

## Publicar (deploy)
Para produção, troque o `provider` do `datasource` em `schema.prisma` de
`sqlite` para `postgresql` (ex. Vercel Postgres, Supabase, Neon) — o SQLite
local não é adequado a ambientes serverless com múltiplas instâncias.

## Integração com GitHub
```bash
git init
git add .
git commit -m "CobraFácil: autenticação, pagamentos, notificações, moeda estrangeira"
git branch -M main
git remote add origin <URL_DO_SEU_REPOSITORIO>
git push -u origin main
```
Nunca faça commit do `.env` (já está no `.gitignore`). Se ligar este
repositório à Vercel, defina lá as mesmas variáveis de `.env.example`.

## Integração com Obsidian
Este projeto não tem uma integração de código com o Obsidian (é uma app de
notas local, sem API pública para isto). Formas práticas de os usar juntos:
- Guarde este `README.md` e notas de decisões de produto/arquitetura numa
  pasta do seu vault (ex. `Projetos/CobraFácil/`) — é Markdown puro.
- Para automatizar, o plugin **Local REST API** do Obsidian expõe um
  endpoint local que pode ser chamado a partir de scripts (não a partir do
  browser da aplicação, por CORS/segurança).

## Notas para continuar o desenvolvimento com o Claude Code
```bash
claude
```
Sugestões de próximos pedidos: paginação nas listagens, exportação de
faturas em PDF, papéis de utilizador adicionais dentro da mesma empresa,
recuperação de palavra-passe, testes automatizados.
