import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  const passwordEmpresa = await bcrypt.hash('empresa123', 12)
  const empresa = await prisma.empresa.upsert({
    where: { email: 'empresa@demo.pt' },
    update: {},
    create: { nome: 'Empresa Demo', email: 'empresa@demo.pt', passwordHash: passwordEmpresa },
  })

  const passwordCliente = await bcrypt.hash('cliente123', 12)
  const cliente = await prisma.cliente.upsert({
    where: { email: 'cliente@demo.pt' },
    update: {},
    create: { nome: 'Cliente Demo', email: 'cliente@demo.pt', passwordHash: passwordCliente, pais: 'PT', empresaId: empresa.id },
  })

  const passwordClienteBr = await bcrypt.hash('cliente123', 12)
  const clienteEstrangeiro = await prisma.cliente.upsert({
    where: { email: 'cliente.br@demo.pt' },
    update: {},
    create: {
      nome: 'Cliente Internacional (BR)',
      email: 'cliente.br@demo.pt',
      passwordHash: passwordClienteBr,
      pais: 'BR',
      empresaId: empresa.id,
    },
  })

  const existentes = await prisma.cobranca.count({ where: { empresaId: empresa.id } })
  if (existentes === 0) {
    await prisma.cobranca.create({
      data: {
        descricao: 'Serviço mensal',
        valor: 120,
        dataLimite: new Date(Date.now() + 6 * 86400000),
        empresaId: empresa.id,
        clienteId: cliente.id,
      },
    })
    await prisma.cobranca.create({
      data: {
        descricao: 'Fatura em atraso',
        valor: 80,
        dataLimite: new Date(Date.now() - 2 * 86400000),
        empresaId: empresa.id,
        clienteId: cliente.id,
        estado: 'EM_ATRASO',
        multaPercentual: 5,
      },
    })
    await prisma.cobranca.create({
      data: {
        descricao: 'Consultoria internacional',
        valor: 250,
        dataLimite: new Date(Date.now() + 10 * 86400000),
        empresaId: empresa.id,
        clienteId: clienteEstrangeiro.id,
      },
    })
  }

  // Taxas de câmbio de referência (podem ser atualizadas depois via
  // atualizarTaxasOnline() ou manualmente).
  const taxas: Record<string, number> = {
    USD: 1.08, GBP: 0.84, BRL: 5.9, AOA: 950, MZN: 68, CVE: 110.27, CHF: 0.94,
  }
  for (const [moeda, taxaPorEur] of Object.entries(taxas)) {
    await prisma.taxaCambio.upsert({ where: { moeda }, update: { taxaPorEur }, create: { moeda, taxaPorEur } })
  }

  console.log('Seed concluído.')
  console.log('Login empresa: empresa@demo.pt / empresa123')
  console.log('Login cliente (PT): cliente@demo.pt / cliente123')
  console.log('Login cliente (BR): cliente.br@demo.pt / cliente123')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(() => prisma.$disconnect())
