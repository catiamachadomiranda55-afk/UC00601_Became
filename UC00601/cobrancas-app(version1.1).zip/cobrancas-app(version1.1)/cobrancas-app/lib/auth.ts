import type { NextAuthOptions } from 'next-auth'
import { getServerSession } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import bcrypt from 'bcryptjs'
import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'

export const authOptions: NextAuthOptions = {
  session: { strategy: 'jwt' },
  pages: { signIn: '/login' },
  providers: [
    CredentialsProvider({
      name: 'Credenciais',
      credentials: {
        email: { label: 'E-mail', type: 'email' },
        password: { label: 'Palavra-passe', type: 'password' },
        perfil: { label: 'Perfil', type: 'text' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials.password || !credentials.perfil) return null
        const email = credentials.email.toLowerCase().trim()

        if (credentials.perfil === 'EMPRESA') {
          const empresa = await prisma.empresa.findUnique({ where: { email } })
          if (!empresa) return null
          const valida = await bcrypt.compare(credentials.password, empresa.passwordHash)
          if (!valida) return null
          return { id: empresa.id, name: empresa.nome, email: empresa.email, role: 'EMPRESA' }
        }

        const cliente = await prisma.cliente.findUnique({ where: { email } })
        if (!cliente) return null
        const valida = await bcrypt.compare(credentials.password, cliente.passwordHash)
        if (!valida) return null
        return { id: cliente.id, name: cliente.nome, email: cliente.email, role: 'CLIENTE' }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
        token.role = user.role
      }
      return token
    },
    async session({ session, token }) {
      session.user.id = token.id
      session.user.role = token.role
      return session
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
}

type SessaoEmpresa = { id: string; name: string; email: string; role: 'EMPRESA' }
type SessaoCliente = { id: string; name: string; email: string; role: 'CLIENTE' }

// Exige sessão de empresa autenticada; redireciona para /login caso contrário.
// Usado em cada página protegida como segunda camada de defesa, além do
// middleware (o middleware sozinho é insuficiente — CVE-2025-29927).
export async function exigirEmpresa(): Promise<SessaoEmpresa> {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')
  if (session.user.role !== 'EMPRESA') redirect('/login')
  return session.user as SessaoEmpresa
}

export async function exigirCliente(): Promise<SessaoCliente> {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')
  if (session.user.role !== 'CLIENTE') redirect('/login')
  return session.user as SessaoCliente
}

export async function obterSessao() {
  return getServerSession(authOptions)
}
