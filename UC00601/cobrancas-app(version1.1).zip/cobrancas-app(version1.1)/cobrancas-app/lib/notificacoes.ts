import { prisma } from '@/lib/prisma'
import { diferencaDias, calcularDesconto, calcularMulta } from '@/lib/rules'
import { enviarEmail } from '@/lib/email'
import type { TipoNotificacao } from '@prisma/client'

type CobrancaComCliente = {
  id: string
  descricao: string
  clienteId: string
  cliente: { email: string }
}

async function criarNotificacao(c: CobrancaComCliente, tipo: TipoNotificacao, mensagem: string) {
  await prisma.notificacao.create({
    data: { tipo, mensagem, cobrancaId: c.id, clienteId: c.clienteId },
  })
  await enviarEmail(c.cliente.email, 'CobraFácil — nova notificação', `<p>${mensagem}</p>`).catch(() => {})
}

// Motor de regras automáticas: aplica descontos, multas e envia avisos.
// Idempotente — cada tipo de aviso só é criado uma vez por cobrança, por isso
// pode ser chamado tanto por um cron externo como oportunisticamente ao abrir
// o dashboard, sem duplicar notificações.
export async function regrasAutomaticas(empresaId?: string) {
  const agora = new Date()
  const cobrancas = await prisma.cobranca.findMany({
    where: { estado: 'PENDENTE', ...(empresaId ? { empresaId } : {}) },
    include: { cliente: true, notificacoes: true },
  })

  let processadas = 0

  for (const c of cobrancas) {
    const dias = diferencaDias(c.dataLimite, agora)
    const jaNotificou = (tipo: TipoNotificacao) => c.notificacoes.some((n) => n.tipo === tipo)

    if (dias < 0) {
      const multaPercentual = calcularMulta(c.dataLimite, agora)
      await prisma.cobranca.update({ where: { id: c.id }, data: { estado: 'EM_ATRASO', multaPercentual } })
      if (!jaNotificou('EM_ATRASO')) {
        await criarNotificacao(c, 'EM_ATRASO', `A cobrança "${c.descricao}" está em atraso. Foi aplicada uma multa de ${multaPercentual}%.`)
      }
      processadas++
      continue
    }

    if (dias === 0 && !jaNotificou('AVISO_ULTIMO_DIA')) {
      await criarNotificacao(c, 'AVISO_ULTIMO_DIA', `Hoje é o último dia para pagar "${c.descricao}". Aceda à sua área de cliente para pagar.`)
      processadas++
    }

    if (dias >= 1 && dias <= 3 && !jaNotificou('AVISO_3_DIAS')) {
      await criarNotificacao(c, 'AVISO_3_DIAS', `Faltam ${dias} dia(s) para o prazo de "${c.descricao}".`)
      processadas++
    }

    if (dias >= 4 && dias <= 7 && !jaNotificou('AVISO_7_DIAS')) {
      const desconto = calcularDesconto(c.dataLimite, agora)
      await prisma.cobranca.update({ where: { id: c.id }, data: { descontoPercentual: { increment: desconto } } })
      await criarNotificacao(c, 'AVISO_7_DIAS', `Pague "${c.descricao}" nos próximos ${dias} dia(s) e beneficie de ${desconto}% de desconto.`)
      processadas++
    }
  }

  return { verificadas: cobrancas.length, processadas }
}
