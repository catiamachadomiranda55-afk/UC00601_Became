// Regras de negócio: descontos, multas e diferença de dias até ao prazo.
// A comparação usa apenas a componente de data (ignora a hora), para que os
// avisos disparem de forma previsível no dia certo.

export function diferencaDias(dataLimite: Date, agora: Date = new Date()) {
  const d1 = Date.UTC(dataLimite.getFullYear(), dataLimite.getMonth(), dataLimite.getDate())
  const d2 = Date.UTC(agora.getFullYear(), agora.getMonth(), agora.getDate())
  return Math.round((d1 - d2) / 86400000)
}

// 7 dias antes (janela 4-7 dias): aviso + 3% de desconto.
export function calcularDesconto(dataLimite: Date, agora: Date = new Date()) {
  const dias = diferencaDias(dataLimite, agora)
  return dias >= 4 && dias <= 7 ? 3 : 0
}

// Depois do prazo: multa de 5%.
export function calcularMulta(dataLimite: Date, agora: Date = new Date()) {
  return diferencaDias(dataLimite, agora) < 0 ? 5 : 0
}
