import { randomBytes } from 'crypto'

export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(' ')
}

export function formatarData(data: Date) {
  return new Intl.DateTimeFormat('pt-PT', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(data)
}

export function gerarPasswordTemporaria(tamanho = 10) {
  return randomBytes(tamanho).toString('base64url').slice(0, tamanho)
}

export const CORES_ESTADO_COBRANCA: Record<string, string> = {
  PENDENTE: 'bg-amber-100 text-amber-800',
  NEGOCIACAO: 'bg-violet-100 text-violet-800',
  PAGO: 'bg-emerald-100 text-emerald-800',
  EM_ATRASO: 'bg-red-100 text-red-800',
}

export const CORES_ESTADO_RECLAMACAO: Record<string, string> = {
  PENDENTE: 'bg-amber-100 text-amber-800',
  EM_ANALISE: 'bg-sky-100 text-sky-800',
  RESOLVIDA: 'bg-emerald-100 text-emerald-800',
}

export const CORES_ESTADO_PRESTACAO: Record<string, string> = {
  PENDENTE: 'bg-amber-100 text-amber-800',
  PAGA: 'bg-emerald-100 text-emerald-800',
}

export const ROTULO_ESTADO: Record<string, string> = {
  PENDENTE: 'Pendente',
  NEGOCIACAO: 'Em negociação',
  PAGO: 'Pago',
  EM_ATRASO: 'Em atraso',
  EM_ANALISE: 'Em análise',
  RESOLVIDA: 'Resolvida',
  PAGA: 'Paga',
}
