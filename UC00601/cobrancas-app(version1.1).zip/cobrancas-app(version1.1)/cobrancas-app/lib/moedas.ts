import { prisma } from '@/lib/prisma'

// Mapeamento país -> moeda ISO. A empresa fatura sempre em EUR (moeda base);
// isto é usado apenas para mostrar/cobrar o valor equivalente ao cliente.
export const MOEDA_POR_PAIS: Record<string, string> = {
  // Zona euro
  PT: 'EUR', ES: 'EUR', FR: 'EUR', DE: 'EUR', IT: 'EUR', NL: 'EUR', BE: 'EUR',
  IE: 'EUR', LU: 'EUR', AT: 'EUR', FI: 'EUR', GR: 'EUR', CY: 'EUR', MT: 'EUR',
  SI: 'EUR', SK: 'EUR', EE: 'EUR', LV: 'EUR', LT: 'EUR', HR: 'EUR',
  // Europa fora da zona euro
  GB: 'GBP', CH: 'CHF', SE: 'SEK', DK: 'DKK', NO: 'NOK',
  PL: 'PLN', CZ: 'CZK', HU: 'HUF', RO: 'RON', BG: 'BGN',
  // Países lusófonos e outros mercados comuns
  BR: 'BRL', AO: 'AOA', MZ: 'MZN', CV: 'CVE',
  US: 'USD', CA: 'CAD', MX: 'MXN', AR: 'ARS',
  CN: 'CNY', JP: 'JPY', IN: 'INR', AU: 'AUD', ZA: 'ZAR', AE: 'AED',
}

// Taxas de referência (1 EUR = X <moeda>). Servem de valor por omissão quando
// não existe registo em TaxaCambio; podem ser atualizadas manualmente na base
// de dados ou automaticamente com atualizarTaxasOnline().
export const TAXAS_REFERENCIA: Record<string, number> = {
  EUR: 1, GBP: 0.84, CHF: 0.94, SEK: 11.3, DKK: 7.46, NOK: 11.6,
  PLN: 4.3, CZK: 25.1, HUF: 395, RON: 4.98, BGN: 1.96,
  BRL: 5.9, AOA: 950, MZN: 68, CVE: 110.27,
  USD: 1.08, CAD: 1.47, MXN: 18.5, ARS: 990,
  CNY: 7.8, JPY: 163, INR: 90, AUD: 1.63, ZAR: 19.8, AED: 3.97,
}

export function moedaPorPais(pais: string): string {
  return MOEDA_POR_PAIS[pais?.toUpperCase()] ?? 'USD'
}

export async function obterTaxa(moeda: string): Promise<number> {
  if (moeda === 'EUR') return 1
  const registo = await prisma.taxaCambio.findUnique({ where: { moeda } })
  return registo?.taxaPorEur ?? TAXAS_REFERENCIA[moeda] ?? 1
}

export function converter(valorEur: number, taxa: number): number {
  return Math.round(valorEur * taxa * 100) / 100
}

export function formatarMoeda(valor: number, moeda: string): string {
  try {
    return new Intl.NumberFormat('pt-PT', { style: 'currency', currency: moeda }).format(valor)
  } catch {
    return `${valor.toFixed(2)} ${moeda}`
  }
}

// Atualização opcional de taxas via API externa (ex.: https://api.frankfurter.app/latest?from=EUR),
// configurada em EXCHANGE_RATE_API_URL. Sem essa variável, o sistema usa TAXAS_REFERENCIA.
export async function atualizarTaxasOnline(): Promise<boolean> {
  const url = process.env.EXCHANGE_RATE_API_URL
  if (!url) return false
  try {
    const resposta = await fetch(url, { cache: 'no-store' })
    if (!resposta.ok) return false
    const dados = (await resposta.json()) as { rates?: Record<string, number>; conversion_rates?: Record<string, number> }
    const taxas = dados.rates ?? dados.conversion_rates ?? {}
    const entradas = Object.entries(taxas).filter(([moeda]) => moeda in TAXAS_REFERENCIA)
    await Promise.all(
      entradas.map(([moeda, taxa]) =>
        prisma.taxaCambio.upsert({
          where: { moeda },
          update: { taxaPorEur: taxa },
          create: { moeda, taxaPorEur: taxa },
        })
      )
    )
    return true
  } catch {
    return false
  }
}
