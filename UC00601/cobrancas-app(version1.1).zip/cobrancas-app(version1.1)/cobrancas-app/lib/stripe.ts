import Stripe from 'stripe'

// Devolve um cliente Stripe apenas se STRIPE_SECRET_KEY estiver configurada.
// Sem chave, os pagamentos por cartão ficam indisponíveis mas o registo
// manual de pagamentos (transferência, referência, etc.) continua a funcionar.
export function obterStripe(): Stripe | null {
  const chave = process.env.STRIPE_SECRET_KEY
  if (!chave) return null
  return new Stripe(chave)
}
