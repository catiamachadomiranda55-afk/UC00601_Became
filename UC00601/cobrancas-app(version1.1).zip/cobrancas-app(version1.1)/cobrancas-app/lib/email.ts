import nodemailer from 'nodemailer'

let transportador: nodemailer.Transporter | null = null

function obterTransportador(): nodemailer.Transporter | null {
  if (transportador) return transportador
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS } = process.env
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) return null
  transportador = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT || 587),
    secure: Number(SMTP_PORT) === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  })
  return transportador
}

// Envia e-mail se houver SMTP configurado; caso contrário regista em consola
// e não interrompe o fluxo (as notificações continuam visíveis na app).
export async function enviarEmail(destinatario: string, assunto: string, html: string) {
  const t = obterTransportador()
  if (!t) {
    console.log(`[e-mail não configurado] Para: ${destinatario} | Assunto: ${assunto}`)
    return
  }
  await t.sendMail({
    from: process.env.SMTP_FROM || 'CobraFácil <no-reply@cobrafacil.app>',
    to: destinatario,
    subject: assunto,
    html,
  })
}
