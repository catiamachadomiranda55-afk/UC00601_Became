<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Badge</title>

    <style>
        .badge {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 12px;
            font-weight: 600;
            font-family: Arial, sans-serif;
        }

        .badge-pago {
            background: #d1fae5;
            color: #047857;
        }

        .badge-pendente {
            background: #fef3c7;
            color: #b45309;
        }

        .badge-atraso {
            background: #fee2e2;
            color: #b91c1c;
        }

        .badge-analise {
            background: #dbeafe;
            color: #1d4ed8;
        }

        .badge-resolvida {
            background: #d1fae5;
            color: #047857;
        }
    </style>
</head>

<body>

    <span class="badge badge-pago">Pago</span>

    <span class="badge badge-pendente">Pendente</span>

    <span class="badge badge-atraso">Em atraso</span>

    <span class="badge badge-analise">Em análise</span>

    <span class="badge badge-resolvida">Resolvida</span>

</body>
</html>