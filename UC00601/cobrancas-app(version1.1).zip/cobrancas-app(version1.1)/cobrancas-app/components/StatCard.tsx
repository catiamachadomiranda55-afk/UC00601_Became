import type { LucideIcon } from 'lucide-react'

export function StatCard({
  label,
  value,
  icon: Icon,
  accent = 'text-slate-900',
}: {
  label: string
  value: string | number
  icon: LucideIcon
  accent?: string
}) {
  return (
    <div className="card flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-slate-500">{label}</p>
        <p className={`mt-1 text-3xl font-bold ${accent}`}>{value}</p>
      </div>
      <div className="rounded-xl bg-slate-100 p-3">
        <Icon className="h-6 w-6 text-slate-500" />
      </div>
    </div>
  )
}
