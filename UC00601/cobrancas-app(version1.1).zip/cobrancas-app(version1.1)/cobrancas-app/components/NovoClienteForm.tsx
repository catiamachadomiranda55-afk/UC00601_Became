'use client'

import { useFormState, useFormStatus } from 'react-dom'
import { criarCliente, type EstadoCriarCliente } from '@/app/clientes/actions'

const PAISES = [
  ['PT', 'Portugal'], ['ES', 'Espanha'], ['FR', 'França'], ['DE', 'Alemanha'],
  ['GB', 'Reino Unido'], ['CH', 'Suíça'], ['BR', 'Brasil'], ['AO', 'Angola'],
  ['MZ', 'Moçambique'], ['CV', 'Cabo Verde'], ['US', 'Estados Unidos'],
  ['CA', 'Canadá'], ['CN', 'China'], ['AU', 'Austrália'], ['ZA', 'África do Sul'],
] as const

const estadoInicial: EstadoCriarCliente = { erro: '', passwordTemporaria: null, emailCliente: null }

function BotaoSubmeter() {
  const { pending } = useFormStatus()
  return (
    <button type="submit" disabled={pending} className="btn w-full">
      {pending ? 'A criar…' : 'Adicionar cliente'}
    </button>
  )
}

export function NovoClienteForm() {
  const [estado, submeter] = useFormState(criarCliente, estadoInicial)

  return (
    <div className="card">
      <h2 className="text-lg font-semibold">Novo cliente</h2>
      <p className="mt-1 text-sm text-slate-500">É gerada uma palavra-passe temporária para o cliente entrar.</p>

      {estado.erro && <p className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{estado.erro}</p>}

      {estado.passwordTemporaria && (
        <div className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
          Cliente criado. Partilhe estas credenciais:
          <br />
          E-mail: <b>{estado.emailCliente}</b>
          <br />
          Palavra-passe temporária: <b>{estado.passwordTemporaria}</b>
        </div>
      )}

      <form action={submeter} className="mt-4 space-y-3">
        <input name="nome" placeholder="Nome do cliente" required className="input" />
        <input name="email" type="email" placeholder="E-mail do cliente" required className="input" />
        <select name="pais" className="input" defaultValue="PT">
          {PAISES.map(([codigo, nome]) => (
            <option key={codigo} value={codigo}>{nome}</option>
          ))}
        </select>
        <BotaoSubmeter />
      </form>
    </div>
  )
}
